//
//  ViewController.swift
//  HobbyHiveRev
//
//  Created by Raihan Daffa Rizky on 11/12/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

