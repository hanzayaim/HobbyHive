//
//  Place.swift
//  HobbyHiveRev
//
//  Created by Raihan Daffa Rizky on 12/12/23.
//

import UIKit

class Place: NSObject {
    var title: String?
    var desc: String?
    var author: String?
    var imgUrl: String?
    var content: String?
}
